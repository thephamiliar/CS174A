Jessica Pham
UID: 004153744

Requirements 1-7: DONE
1. Got simple WebGL window to display without error.
2. Loaded image into texture map buffer.
3. Cube #3: Applied entire texture to face of cube with standard texture coordinates.
4. Cube #4: Made second cube that is zoomed out and centered.
5. Made Cube #3 filtered with nearest neighbor and Cube #4 filtered with tri-linear filtering.
6. Made both cubes visible in starting camera view.
7. Keyboard navigation system
	Overview of keyboard actions:
		'i' = moves camera nearer to cubes
		'o' = moves camera farther away from cubes

Extra Credit 1-3: DONE
Overview of keyboard actions:
	'r' = cubes will start/stop rotating
		Cube #3 rotates about y-axis, 60RPM
		Cube #4 rotates about x-axis, 30RPM
	't' = texture map for Cube #3 will start/stop rotating at 60RPM
	's' = texture map for Cube #4 will start/stop scrolling